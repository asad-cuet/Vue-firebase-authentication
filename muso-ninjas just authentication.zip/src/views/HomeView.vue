<template>
  <div class="home" style="text-align: center;">
      <h3>Home Page</h3>
  </div>
</template>

<script>
export default {
  name: 'HomeView',
  setup()
  {

  },
  components: {

  }
}
</script>
